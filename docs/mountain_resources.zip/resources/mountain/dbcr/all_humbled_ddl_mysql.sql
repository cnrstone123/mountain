/*
	ALTER TABLE ids                         COMMENT '# ID Generation';
	ALTER TABLE letTcCmmnClcode             COMMENT '# 분류코드';
	ALTER TABLE letTcCmmnCode               COMMENT '# 공통코드';
	ALTER TABLE letTcCmmnDetailcode         COMMENT '# 공통상세코드';
	ALTER TABLE letTcZip                    COMMENT '# 우편번호';
	
	ALTER TABLE letTnRoleinfo               COMMENT '# 롤정보';
	ALTER TABLE letTnRoles_hierarchy        COMMENT '# 권한(롤)계층정보';
	
	ALTER TABLE letTnAuthorGroupInfo        COMMENT '# 그룹정보';
	ALTER TABLE letTnAuthorinfo             COMMENT '# 권한정보';
	ALTER TABLE letTnAuthorRoleRelate       COMMENT '# 권한별 롤';
	
	ALTER TABLE letTnLoginlog               COMMENT '## 로그인로그';
	ALTER TABLE letTnLoginpolicy            COMMENT '## 로그인정책';
	
	ALTER TABLE letTnGnrlMber               COMMENT '## 일반회원';
	ALTER TABLE letTnEmplyrInfo             COMMENT '# 사용자정보';
	ALTER TABLE letTnEmplyrScrtYestbs       COMMENT '# 사용자별권한설정';
	ALTER TABLE letThEmplyrInfoChangeDtls   COMMENT '';
	ALTER TABLE letTnEntrprsMber            COMMENT '## 기업회원';
	ALTER TABLE letTnOrgnztInfo             COMMENT '# 조직정보';
	ALTER TABLE letTnUserabsnce             COMMENT '## 사용자부재';
	
	ALTER TABLE letTnFile                   COMMENT '## 파일';
	ALTER TABLE letTnFileDetail             COMMENT '## 파일상세';
	
	ALTER TABLE letTnMenuInfo               COMMENT '# 메뉴목록';
	ALTER TABLE letTnMenuCreatDtls          COMMENT '# 메뉴생성목록상세';
	
	ALTER TABLE letTnProgrmlist             COMMENT '# 프로그램목록';
	
	ALTER TABLE letTnTmplatinfo             COMMENT '# 게시판템플릿';
	ALTER TABLE letTnBbs                    COMMENT '# 게시물';
	ALTER TABLE letTnBbsmaster              COMMENT '# 게시판마스터';
	ALTER TABLE letTnBbsmasteroptn          COMMENT '## 게시판마스터옵션';
	
	ALTER TABLE letTnBbsuse                 COMMENT '# 게시판사용';
	ALTER TABLE letTsSyslogsummary          COMMENT '## 시스템로그 요약정보';
	
	ALTER TABLE sample                      COMMENT '# sample';
	ALTER TABLE tb_mountain                 COMMENT '# sample';

*	comvnusermaster              '## view';
*/

-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               5.6.21-log - MySQL Community Server (GPL)
-- Server OS:                    Win32
-- HeidiSQL Version:             9.5.0.5201
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for humbled
DROP DATABASE IF EXISTS `humbled`;
CREATE DATABASE IF NOT EXISTS `humbled` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `humbled`;

-- Dumping structure for table humbled.ids
DROP TABLE IF EXISTS `ids`;
CREATE TABLE IF NOT EXISTS `ids` (
  `TABLE_NAME` varchar(20) NOT NULL,
  `NEXT_ID` decimal(30,0) NOT NULL DEFAULT '0',
  PRIMARY KEY (`TABLE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettccmmnclcode
DROP TABLE IF EXISTS `lettccmmnclcode`;
CREATE TABLE IF NOT EXISTS `lettccmmnclcode` (
  `CL_CODE` char(3) NOT NULL,
  `CL_CODE_NM` varchar(60) DEFAULT NULL,
  `CL_CODE_DC` varchar(200) DEFAULT NULL,
  `USE_AT` char(1) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CL_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettccmmncode
DROP TABLE IF EXISTS `lettccmmncode`;
CREATE TABLE IF NOT EXISTS `lettccmmncode` (
  `CODE_ID` varchar(6) NOT NULL,
  `CODE_ID_NM` varchar(60) DEFAULT NULL,
  `CODE_ID_DC` varchar(200) DEFAULT NULL,
  `USE_AT` char(1) DEFAULT NULL,
  `CL_CODE` char(3) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CODE_ID`),
  KEY `R_179` (`CL_CODE`),
  CONSTRAINT `LETTCCMMNCODE_ibfk_1` FOREIGN KEY (`CL_CODE`) REFERENCES `lettccmmnclcode` (`CL_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettccmmndetailcode
DROP TABLE IF EXISTS `lettccmmndetailcode`;
CREATE TABLE IF NOT EXISTS `lettccmmndetailcode` (
  `CODE_ID` varchar(6) NOT NULL,
  `CODE` varchar(15) NOT NULL,
  `CODE_NM` varchar(60) DEFAULT NULL,
  `CODE_DC` varchar(200) DEFAULT NULL,
  `USE_AT` char(1) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`CODE_ID`,`CODE`),
  CONSTRAINT `LETTCCMMNDETAILCODE_ibfk_1` FOREIGN KEY (`CODE_ID`) REFERENCES `lettccmmncode` (`CODE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettczip
DROP TABLE IF EXISTS `lettczip`;
CREATE TABLE IF NOT EXISTS `lettczip` (
  `ZIP` varchar(6) NOT NULL,
  `SN` decimal(10,0) NOT NULL DEFAULT '0',
  `CTPRVN_NM` varchar(20) DEFAULT NULL,
  `SIGNGU_NM` varchar(20) DEFAULT NULL,
  `EMD_NM` varchar(60) DEFAULT NULL,
  `LI_BULD_NM` varchar(60) DEFAULT NULL,
  `LNBR_DONG_HO` varchar(20) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ZIP`,`SN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.letthemplyrinfochangedtls
DROP TABLE IF EXISTS `letthemplyrinfochangedtls`;
CREATE TABLE IF NOT EXISTS `letthemplyrinfochangedtls` (
  `EMPLYR_ID` varchar(20) NOT NULL,
  `CHANGE_DE` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `ORGNZT_ID` char(20) DEFAULT NULL,
  `GROUP_ID` char(20) DEFAULT NULL,
  `EMPL_NO` varchar(20) DEFAULT NULL,
  `SEXDSTN_CODE` char(1) DEFAULT NULL,
  `BRTHDY` char(20) DEFAULT NULL,
  `FXNUM` varchar(20) DEFAULT NULL,
  `HOUSE_ADRES` varchar(100) DEFAULT NULL,
  `HOUSE_END_TELNO` varchar(4) DEFAULT NULL,
  `AREA_NO` varchar(4) DEFAULT NULL,
  `DETAIL_ADRES` varchar(100) DEFAULT NULL,
  `ZIP` varchar(6) DEFAULT NULL,
  `OFFM_TELNO` varchar(20) DEFAULT NULL,
  `MBTLNUM` varchar(20) DEFAULT NULL,
  `EMAIL_ADRES` varchar(50) DEFAULT NULL,
  `HOUSE_MIDDLE_TELNO` varchar(4) DEFAULT NULL,
  `PSTINST_CODE` char(8) DEFAULT NULL,
  `EMPLYR_STTUS_CODE` varchar(15) DEFAULT NULL,
  `ESNTL_ID` char(20) DEFAULT NULL,
  PRIMARY KEY (`EMPLYR_ID`,`CHANGE_DE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnauthorgroupinfo
DROP TABLE IF EXISTS `lettnauthorgroupinfo`;
CREATE TABLE IF NOT EXISTS `lettnauthorgroupinfo` (
  `GROUP_ID` char(20) NOT NULL DEFAULT '',
  `GROUP_NM` varchar(60) NOT NULL,
  `GROUP_CREAT_DE` char(20) NOT NULL,
  `GROUP_DC` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`GROUP_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnauthorinfo
DROP TABLE IF EXISTS `lettnauthorinfo`;
CREATE TABLE IF NOT EXISTS `lettnauthorinfo` (
  `AUTHOR_CODE` varchar(30) NOT NULL DEFAULT '',
  `AUTHOR_NM` varchar(60) NOT NULL,
  `AUTHOR_DC` varchar(200) DEFAULT NULL,
  `AUTHOR_CREAT_DE` char(20) NOT NULL,
  PRIMARY KEY (`AUTHOR_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnauthorrolerelate
DROP TABLE IF EXISTS `lettnauthorrolerelate`;
CREATE TABLE IF NOT EXISTS `lettnauthorrolerelate` (
  `AUTHOR_CODE` varchar(30) NOT NULL,
  `ROLE_CODE` varchar(50) NOT NULL,
  `CREAT_DT` datetime DEFAULT NULL,
  PRIMARY KEY (`AUTHOR_CODE`,`ROLE_CODE`),
  KEY `R_292` (`ROLE_CODE`),
  CONSTRAINT `LETTNAUTHORROLERELATE_ibfk_1` FOREIGN KEY (`AUTHOR_CODE`) REFERENCES `lettnauthorinfo` (`AUTHOR_CODE`) ON DELETE CASCADE,
  CONSTRAINT `LETTNAUTHORROLERELATE_ibfk_2` FOREIGN KEY (`ROLE_CODE`) REFERENCES `lettnroleinfo` (`ROLE_CODE`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnbbs
DROP TABLE IF EXISTS `lettnbbs`;
CREATE TABLE IF NOT EXISTS `lettnbbs` (
  `NTT_ID` decimal(20,0) NOT NULL,
  `BBS_ID` char(20) NOT NULL,
  `NTT_NO` decimal(20,0) DEFAULT NULL,
  `NTT_SJ` varchar(2000) DEFAULT NULL,
  `NTT_CN` mediumtext,
  `ANSWER_AT` char(1) DEFAULT NULL,
  `PARNTSCTT_NO` decimal(10,0) DEFAULT NULL,
  `ANSWER_LC` int(11) DEFAULT NULL,
  `SORT_ORDR` decimal(8,0) DEFAULT NULL,
  `RDCNT` decimal(10,0) DEFAULT NULL,
  `USE_AT` char(1) NOT NULL,
  `NTCE_BGNDE` char(20) DEFAULT NULL,
  `NTCE_ENDDE` char(20) DEFAULT NULL,
  `NTCR_ID` varchar(20) DEFAULT NULL,
  `NTCR_NM` varchar(20) DEFAULT NULL,
  `PASSWORD` varchar(200) DEFAULT NULL,
  `ATCH_FILE_ID` char(20) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime NOT NULL,
  `FRST_REGISTER_ID` varchar(20) NOT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`NTT_ID`,`BBS_ID`),
  KEY `LETTNBBS_ibfk_1` (`BBS_ID`),
  CONSTRAINT `LETTNBBS_ibfk_1` FOREIGN KEY (`BBS_ID`) REFERENCES `lettnbbsmaster` (`BBS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnbbsmaster
DROP TABLE IF EXISTS `lettnbbsmaster`;
CREATE TABLE IF NOT EXISTS `lettnbbsmaster` (
  `BBS_ID` char(20) NOT NULL,
  `BBS_NM` varchar(255) NOT NULL,
  `BBS_INTRCN` varchar(2400) DEFAULT NULL,
  `BBS_TY_CODE` char(6) NOT NULL,
  `BBS_ATTRB_CODE` char(6) NOT NULL,
  `REPLY_POSBL_AT` char(1) DEFAULT NULL,
  `FILE_ATCH_POSBL_AT` char(1) NOT NULL,
  `ATCH_POSBL_FILE_NUMBER` decimal(2,0) NOT NULL,
  `ATCH_POSBL_FILE_SIZE` decimal(8,0) DEFAULT NULL,
  `USE_AT` char(1) NOT NULL,
  `TMPLAT_ID` char(20) DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) NOT NULL,
  `FRST_REGIST_PNTTM` datetime NOT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  PRIMARY KEY (`BBS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnbbsmasteroptn
DROP TABLE IF EXISTS `lettnbbsmasteroptn`;
CREATE TABLE IF NOT EXISTS `lettnbbsmasteroptn` (
  `BBS_ID` char(20) NOT NULL DEFAULT '',
  `ANSWER_AT` char(1) NOT NULL DEFAULT '',
  `STSFDG_AT` char(1) NOT NULL DEFAULT '',
  `FRST_REGIST_PNTTM` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) NOT NULL DEFAULT '',
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`BBS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnbbsuse
DROP TABLE IF EXISTS `lettnbbsuse`;
CREATE TABLE IF NOT EXISTS `lettnbbsuse` (
  `BBS_ID` char(20) NOT NULL,
  `TRGET_ID` char(20) NOT NULL DEFAULT '',
  `USE_AT` char(1) NOT NULL,
  `REGIST_SE_CODE` char(6) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) NOT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`BBS_ID`,`TRGET_ID`),
  CONSTRAINT `LETTNBBSUSE_ibfk_1` FOREIGN KEY (`BBS_ID`) REFERENCES `lettnbbsmaster` (`BBS_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnemplyrinfo
DROP TABLE IF EXISTS `lettnemplyrinfo`;
CREATE TABLE IF NOT EXISTS `lettnemplyrinfo` (
  `EMPLYR_ID` varchar(20) NOT NULL,
  `ORGNZT_ID` char(20) DEFAULT NULL,
  `USER_NM` varchar(60) NOT NULL,
  `PASSWORD` varchar(200) NOT NULL,
  `EMPL_NO` varchar(20) DEFAULT NULL,
  `IHIDNUM` varchar(200) DEFAULT NULL,
  `SEXDSTN_CODE` char(1) DEFAULT NULL,
  `BRTHDY` char(20) DEFAULT NULL,
  `FXNUM` varchar(20) DEFAULT NULL,
  `HOUSE_ADRES` varchar(100) DEFAULT NULL,
  `PASSWORD_HINT` varchar(100) NOT NULL,
  `PASSWORD_CNSR` varchar(100) NOT NULL,
  `HOUSE_END_TELNO` varchar(4) DEFAULT NULL,
  `AREA_NO` varchar(4) DEFAULT NULL,
  `DETAIL_ADRES` varchar(100) DEFAULT NULL,
  `ZIP` varchar(6) DEFAULT NULL,
  `OFFM_TELNO` varchar(20) DEFAULT NULL,
  `MBTLNUM` varchar(20) DEFAULT NULL,
  `EMAIL_ADRES` varchar(50) DEFAULT NULL,
  `OFCPS_NM` varchar(60) DEFAULT NULL,
  `HOUSE_MIDDLE_TELNO` varchar(4) DEFAULT NULL,
  `GROUP_ID` char(20) DEFAULT NULL,
  `PSTINST_CODE` char(8) DEFAULT NULL,
  `EMPLYR_STTUS_CODE` varchar(15) NOT NULL,
  `ESNTL_ID` char(20) NOT NULL,
  `CRTFC_DN_VALUE` varchar(20) DEFAULT NULL,
  `SBSCRB_DE` datetime DEFAULT NULL,
  PRIMARY KEY (`EMPLYR_ID`),
  KEY `LETTNEMPLYRINFO_ibfk_2` (`GROUP_ID`),
  KEY `LETTNEMPLYRINFO_ibfk_1` (`ORGNZT_ID`),
  CONSTRAINT `LETTNEMPLYRINFO_ibfk_1` FOREIGN KEY (`ORGNZT_ID`) REFERENCES `lettnorgnztinfo` (`ORGNZT_ID`) ON DELETE CASCADE,
  CONSTRAINT `LETTNEMPLYRINFO_ibfk_2` FOREIGN KEY (`GROUP_ID`) REFERENCES `lettnauthorgroupinfo` (`GROUP_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnemplyrscrtyestbs
DROP TABLE IF EXISTS `lettnemplyrscrtyestbs`;
CREATE TABLE IF NOT EXISTS `lettnemplyrscrtyestbs` (
  `SCRTY_DTRMN_TRGET_ID` varchar(20) NOT NULL,
  `MBER_TY_CODE` varchar(15) DEFAULT NULL,
  `AUTHOR_CODE` varchar(30) NOT NULL,
  PRIMARY KEY (`SCRTY_DTRMN_TRGET_ID`),
  KEY `LETTNEMPLYRSCRTYESTBS_ibfk_4` (`AUTHOR_CODE`),
  CONSTRAINT `LETTNEMPLYRSCRTYESTBS_ibfk_4` FOREIGN KEY (`AUTHOR_CODE`) REFERENCES `lettnauthorinfo` (`AUTHOR_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnentrprsmber
DROP TABLE IF EXISTS `lettnentrprsmber`;
CREATE TABLE IF NOT EXISTS `lettnentrprsmber` (
  `ENTRPRS_MBER_ID` varchar(20) NOT NULL DEFAULT '',
  `ENTRPRS_SE_CODE` char(15) DEFAULT NULL,
  `BIZRNO` varchar(10) DEFAULT NULL,
  `JURIRNO` varchar(13) DEFAULT NULL,
  `CMPNY_NM` varchar(60) NOT NULL,
  `CXFC` varchar(50) DEFAULT NULL,
  `ZIP` varchar(6) DEFAULT NULL,
  `ADRES` varchar(100) DEFAULT NULL,
  `ENTRPRS_MIDDLE_TELNO` varchar(4) DEFAULT NULL,
  `FXNUM` varchar(20) DEFAULT NULL,
  `INDUTY_CODE` char(15) DEFAULT NULL,
  `APPLCNT_NM` varchar(50) DEFAULT NULL,
  `APPLCNT_IHIDNUM` varchar(200) DEFAULT NULL,
  `SBSCRB_DE` datetime DEFAULT NULL,
  `ENTRPRS_MBER_STTUS` varchar(15) DEFAULT NULL,
  `ENTRPRS_MBER_PASSWORD` varchar(200) NOT NULL,
  `ENTRPRS_MBER_PASSWORD_HINT` varchar(100) NOT NULL,
  `ENTRPRS_MBER_PASSWORD_CNSR` varchar(100) NOT NULL,
  `GROUP_ID` char(20) DEFAULT NULL,
  `DETAIL_ADRES` varchar(100) DEFAULT NULL,
  `ENTRPRS_END_TELNO` varchar(4) DEFAULT NULL,
  `AREA_NO` varchar(4) DEFAULT NULL,
  `APPLCNT_EMAIL_ADRES` varchar(50) DEFAULT NULL,
  `ESNTL_ID` char(20) NOT NULL,
  PRIMARY KEY (`ENTRPRS_MBER_ID`),
  KEY `LETTNENTRPRSMBER_ibfk_1` (`GROUP_ID`),
  CONSTRAINT `LETTNENTRPRSMBER_ibfk_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `lettnauthorgroupinfo` (`GROUP_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnfile
DROP TABLE IF EXISTS `lettnfile`;
CREATE TABLE IF NOT EXISTS `lettnfile` (
  `ATCH_FILE_ID` char(20) NOT NULL,
  `CREAT_DT` datetime NOT NULL,
  `USE_AT` char(1) DEFAULT NULL,
  PRIMARY KEY (`ATCH_FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnfiledetail
DROP TABLE IF EXISTS `lettnfiledetail`;
CREATE TABLE IF NOT EXISTS `lettnfiledetail` (
  `ATCH_FILE_ID` char(20) NOT NULL,
  `FILE_SN` decimal(10,0) NOT NULL,
  `FILE_STRE_COURS` varchar(2000) NOT NULL,
  `STRE_FILE_NM` varchar(255) NOT NULL,
  `ORIGNL_FILE_NM` varchar(255) DEFAULT NULL,
  `FILE_EXTSN` varchar(20) NOT NULL,
  `FILE_CN` mediumtext,
  `FILE_SIZE` decimal(8,0) DEFAULT NULL,
  PRIMARY KEY (`ATCH_FILE_ID`,`FILE_SN`),
  CONSTRAINT `LETTNFILEDETAIL_ibfk_1` FOREIGN KEY (`ATCH_FILE_ID`) REFERENCES `lettnfile` (`ATCH_FILE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettngnrlmber
DROP TABLE IF EXISTS `lettngnrlmber`;
CREATE TABLE IF NOT EXISTS `lettngnrlmber` (
  `MBER_ID` varchar(20) NOT NULL DEFAULT '',
  `PASSWORD` varchar(200) NOT NULL,
  `PASSWORD_HINT` varchar(100) DEFAULT NULL,
  `PASSWORD_CNSR` varchar(100) DEFAULT NULL,
  `IHIDNUM` varchar(200) DEFAULT NULL,
  `MBER_NM` varchar(50) NOT NULL,
  `ZIP` varchar(6) DEFAULT NULL,
  `ADRES` varchar(100) DEFAULT NULL,
  `AREA_NO` varchar(4) DEFAULT NULL,
  `MBER_STTUS` varchar(15) DEFAULT NULL,
  `DETAIL_ADRES` varchar(100) DEFAULT NULL,
  `END_TELNO` varchar(4) DEFAULT NULL,
  `MBTLNUM` varchar(20) DEFAULT NULL,
  `GROUP_ID` char(20) DEFAULT NULL,
  `MBER_FXNUM` varchar(20) DEFAULT NULL,
  `MBER_EMAIL_ADRES` varchar(50) DEFAULT NULL,
  `MIDDLE_TELNO` varchar(4) DEFAULT NULL,
  `SBSCRB_DE` datetime DEFAULT NULL,
  `SEXDSTN_CODE` char(1) DEFAULT NULL,
  `ESNTL_ID` char(20) NOT NULL,
  PRIMARY KEY (`MBER_ID`),
  KEY `LETTNGNRLMBER_ibfk_1` (`GROUP_ID`),
  CONSTRAINT `LETTNGNRLMBER_ibfk_1` FOREIGN KEY (`GROUP_ID`) REFERENCES `lettnauthorgroupinfo` (`GROUP_ID`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnloginlog
DROP TABLE IF EXISTS `lettnloginlog`;
CREATE TABLE IF NOT EXISTS `lettnloginlog` (
  `LOG_ID` char(20) NOT NULL,
  `CONECT_ID` varchar(20) DEFAULT NULL,
  `CONECT_IP` varchar(23) DEFAULT NULL,
  `CONECT_MTHD` char(4) DEFAULT NULL,
  `ERROR_OCCRRNC_AT` char(1) DEFAULT NULL,
  `ERROR_CODE` char(3) DEFAULT NULL,
  `CREAT_DT` datetime DEFAULT NULL,
  PRIMARY KEY (`LOG_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnloginpolicy
DROP TABLE IF EXISTS `lettnloginpolicy`;
CREATE TABLE IF NOT EXISTS `lettnloginpolicy` (
  `EMPLYR_ID` varchar(20) NOT NULL DEFAULT '',
  `IP_INFO` varchar(23) NOT NULL,
  `DPLCT_PERM_AT` char(1) NOT NULL,
  `LMTT_AT` char(1) NOT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  PRIMARY KEY (`EMPLYR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnmenucreatdtls
DROP TABLE IF EXISTS `lettnmenucreatdtls`;
CREATE TABLE IF NOT EXISTS `lettnmenucreatdtls` (
  `MENU_NO` decimal(20,0) NOT NULL,
  `AUTHOR_CODE` varchar(30) NOT NULL,
  `MAPNG_CREAT_ID` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`MENU_NO`,`AUTHOR_CODE`),
  KEY `R_247` (`MAPNG_CREAT_ID`),
  KEY `R_303` (`AUTHOR_CODE`),
  CONSTRAINT `LETTNMENUCREATDTLS_ibfk_1` FOREIGN KEY (`MENU_NO`) REFERENCES `lettnmenuinfo` (`MENU_NO`) ON DELETE CASCADE,
  CONSTRAINT `LETTNMENUCREATDTLS_ibfk_3` FOREIGN KEY (`AUTHOR_CODE`) REFERENCES `lettnauthorinfo` (`AUTHOR_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnmenuinfo
DROP TABLE IF EXISTS `lettnmenuinfo`;
CREATE TABLE IF NOT EXISTS `lettnmenuinfo` (
  `MENU_NM` varchar(60) NOT NULL,
  `PROGRM_FILE_NM` varchar(60) NOT NULL,
  `MENU_NO` decimal(20,0) NOT NULL,
  `UPPER_MENU_NO` decimal(20,0) DEFAULT NULL,
  `MENU_ORDR` decimal(5,0) NOT NULL,
  `MENU_DC` varchar(250) DEFAULT NULL,
  `RELATE_IMAGE_PATH` varchar(100) DEFAULT NULL,
  `RELATE_IMAGE_NM` varchar(60) DEFAULT NULL,
  PRIMARY KEY (`MENU_NO`),
  KEY `R_2` (`PROGRM_FILE_NM`),
  KEY `R_4` (`UPPER_MENU_NO`),
  CONSTRAINT `LETTNMENUINFO_ibfk_1` FOREIGN KEY (`PROGRM_FILE_NM`) REFERENCES `lettnprogrmlist` (`PROGRM_FILE_NM`) ON DELETE CASCADE,
  CONSTRAINT `LETTNMENUINFO_ibfk_2` FOREIGN KEY (`UPPER_MENU_NO`) REFERENCES `lettnmenuinfo` (`MENU_NO`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnorgnztinfo
DROP TABLE IF EXISTS `lettnorgnztinfo`;
CREATE TABLE IF NOT EXISTS `lettnorgnztinfo` (
  `ORGNZT_ID` char(20) NOT NULL DEFAULT '',
  `ORGNZT_NM` varchar(20) NOT NULL,
  `ORGNZT_DC` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ORGNZT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnprogrmlist
DROP TABLE IF EXISTS `lettnprogrmlist`;
CREATE TABLE IF NOT EXISTS `lettnprogrmlist` (
  `PROGRM_FILE_NM` varchar(60) NOT NULL DEFAULT '',
  `PROGRM_STRE_PATH` varchar(100) NOT NULL,
  `PROGRM_KOREAN_NM` varchar(60) DEFAULT NULL,
  `PROGRM_DC` varchar(200) DEFAULT NULL,
  `URL` varchar(100) NOT NULL,
  PRIMARY KEY (`PROGRM_FILE_NM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnroleinfo
DROP TABLE IF EXISTS `lettnroleinfo`;
CREATE TABLE IF NOT EXISTS `lettnroleinfo` (
  `ROLE_CODE` varchar(50) NOT NULL DEFAULT '',
  `ROLE_NM` varchar(60) NOT NULL,
  `ROLE_PTTRN` varchar(300) DEFAULT NULL,
  `ROLE_DC` varchar(200) DEFAULT NULL,
  `ROLE_TY` varchar(80) DEFAULT NULL,
  `ROLE_SORT` varchar(10) DEFAULT NULL,
  `ROLE_CREAT_DE` char(20) NOT NULL,
  PRIMARY KEY (`ROLE_CODE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnroles_hierarchy
DROP TABLE IF EXISTS `lettnroles_hierarchy`;
CREATE TABLE IF NOT EXISTS `lettnroles_hierarchy` (
  `PARNTS_ROLE` varchar(30) NOT NULL,
  `CHLDRN_ROLE` varchar(30) NOT NULL,
  PRIMARY KEY (`PARNTS_ROLE`,`CHLDRN_ROLE`),
  KEY `R_308` (`CHLDRN_ROLE`),
  CONSTRAINT `LETTNROLES_HIERARCHY_ibfk_1` FOREIGN KEY (`PARNTS_ROLE`) REFERENCES `lettnauthorinfo` (`AUTHOR_CODE`) ON DELETE CASCADE,
  CONSTRAINT `LETTNROLES_HIERARCHY_ibfk_2` FOREIGN KEY (`CHLDRN_ROLE`) REFERENCES `lettnauthorinfo` (`AUTHOR_CODE`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettntmplatinfo
DROP TABLE IF EXISTS `lettntmplatinfo`;
CREATE TABLE IF NOT EXISTS `lettntmplatinfo` (
  `TMPLAT_ID` char(20) NOT NULL DEFAULT '',
  `TMPLAT_NM` varchar(255) DEFAULT NULL,
  `TMPLAT_COURS` varchar(2000) DEFAULT NULL,
  `USE_AT` char(1) DEFAULT NULL,
  `TMPLAT_SE_CODE` char(6) DEFAULT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  PRIMARY KEY (`TMPLAT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettnuserabsnce
DROP TABLE IF EXISTS `lettnuserabsnce`;
CREATE TABLE IF NOT EXISTS `lettnuserabsnce` (
  `EMPLYR_ID` varchar(20) NOT NULL DEFAULT '',
  `USER_ABSNCE_AT` char(1) NOT NULL,
  `FRST_REGISTER_ID` varchar(20) DEFAULT NULL,
  `FRST_REGIST_PNTTM` datetime DEFAULT NULL,
  `LAST_UPDUSR_ID` varchar(20) DEFAULT NULL,
  `LAST_UPDT_PNTTM` datetime DEFAULT NULL,
  PRIMARY KEY (`EMPLYR_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.lettssyslogsummary
DROP TABLE IF EXISTS `lettssyslogsummary`;
CREATE TABLE IF NOT EXISTS `lettssyslogsummary` (
  `OCCRRNC_DE` char(20) NOT NULL,
  `SRVC_NM` varchar(255) NOT NULL,
  `METHOD_NM` varchar(60) NOT NULL,
  `CREAT_CO` decimal(10,0) DEFAULT NULL,
  `UPDT_CO` decimal(10,0) DEFAULT NULL,
  `RDCNT` decimal(10,0) DEFAULT NULL,
  `DELETE_CO` decimal(10,0) DEFAULT NULL,
  `OUTPT_CO` decimal(10,0) DEFAULT NULL,
  `ERROR_CO` decimal(10,0) DEFAULT NULL,
  PRIMARY KEY (`OCCRRNC_DE`,`SRVC_NM`,`METHOD_NM`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.sample
DROP TABLE IF EXISTS `sample`;
CREATE TABLE IF NOT EXISTS `sample` (
  `ID` varchar(16) NOT NULL,
  `NAME` varchar(50) DEFAULT NULL,
  `DESCRIPTION` varchar(100) DEFAULT NULL,
  `USE_YN` char(1) DEFAULT NULL,
  `REG_USER` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Data exporting was unselected.
-- Dumping structure for table humbled.tb_mountain
DROP TABLE IF EXISTS `tb_mountain`;
CREATE TABLE IF NOT EXISTS `tb_mountain` (
  `dateTime` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `abs` varchar(200) DEFAULT NULL,
  `desc` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`dateTime`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='for memo related with database ''humbled''.\r\n';

-- Data exporting was unselected.
-- Dumping structure for view humbled.comvnusermaster
DROP VIEW IF EXISTS `comvnusermaster`;
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `comvnusermaster` (
	`ESNTL_ID` CHAR(20) NOT NULL COLLATE 'utf8_general_ci',
	`USER_ID` VARCHAR(20) NOT NULL COLLATE 'utf8_general_ci',
	`PASSWORD` VARCHAR(200) NOT NULL COLLATE 'utf8_general_ci',
	`USER_NM` VARCHAR(60) NOT NULL COLLATE 'utf8_general_ci',
	`USER_ZIP` VARCHAR(6) NULL COLLATE 'utf8_general_ci',
	`USER_ADRES` VARCHAR(100) NULL COLLATE 'utf8_general_ci',
	`USER_EMAIL` VARCHAR(50) NULL COLLATE 'utf8_general_ci',
	`GROUP_ID` VARCHAR(20) NULL COLLATE 'utf8_general_ci',
	`USER_SE` VARCHAR(3) NOT NULL COLLATE 'utf8mb4_general_ci',
	`ORGNZT_ID` VARCHAR(20) NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for view humbled.comvnusermaster
DROP VIEW IF EXISTS `comvnusermaster`;
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `comvnusermaster`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `comvnusermaster` AS SELECT ESNTL_ID, MBER_ID,PASSWORD,MBER_NM,ZIP,ADRES,MBER_EMAIL_ADRES,' ','GNR' AS USER_SE, ' ' ORGNZT_ID
        FROM LETTNGNRLMBER
    UNION ALL
        SELECT ESNTL_ID,EMPLYR_ID,PASSWORD,USER_NM,ZIP,HOUSE_ADRES,EMAIL_ADRES,GROUP_ID ,'USR' AS USER_SE, ORGNZT_ID
        FROM LETTNEMPLYRINFO
    UNION ALL
        SELECT ESNTL_ID,ENTRPRS_MBER_ID,ENTRPRS_MBER_PASSWORD,CMPNY_NM,ZIP,ADRES,APPLCNT_EMAIL_ADRES,' ' ,'ENT' AS USER_SE, ' ' ORGNZT_ID
        FROM LETTNENTRPRSMBER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
